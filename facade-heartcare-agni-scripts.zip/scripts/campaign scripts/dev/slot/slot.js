/**
 * FHIR Slot - Add serviceType (Facility) Updater
 *
 * Usage:
 *   node update-Slot-service-type.js --env dev --token <your_token>
 *   node update-Slot-service-type.js --env prod --token <your_token>
 *   node update-Slot-service-type.js --env dev --token <your_token> --dry-run
 *
 * Alternatively, set the token via environment variable (recommended for prod):
 *   FHIR_TOKEN=<your_token> node update-Slot-service-type.js --env prod
 *
 * Requirements:
 *   - Node.js 18+
 *   - A Slot.json file in the same directory (FHIR Bundle or array of Slot resources)
 */

"use strict";

const fs    = require("fs");
const path  = require("path");
const http  = require("http");
const https = require("https");

// ─── CONFIG ──────────────────────────────────────────────────────────────────

const SERVER_URLS = {
  dev:  "http://143.110.253.49/fhir",
  test: "http://test-server/fhir",   // update as needed
  prod: "http://prod-server/fhir",   // update as needed
};

const SERVICE_TYPE_TO_ADD = [
  {
    coding: [
      {
        system:  "http://terminology.hl7.org/CodeSystem/service-type",
        code:    "facility",
        display: "facility",
      },
    ],
  },
];

const SlotS_FILE = path.join(__dirname, "slot.json");

// ─── CLI ARGS ─────────────────────────────────────────────────────────────────

function parseCliArgs() {
  const args = process.argv.slice(2);
  const get  = (flag) => { const i = args.indexOf(flag); return i !== -1 ? args[i + 1] : undefined; };
  const has  = (flag) => args.includes(flag);

  const env       = get("--env") ?? get("-e") ?? "dev";
  const customUrl = get("--base-url");
  const dryRun    = has("--dry-run");
  const baseUrl   = customUrl ?? SERVER_URLS[env];

  // Token: --token flag takes priority, then FHIR_TOKEN env var
  const token = "eyJhbGciOiJIUzI1NiJ9.eyJhY2NvdW50X2NyZWF0aW9uX3RpbWVzdGFtcCI6IjIwMjYtMDMtMTFUMDg6MTg6MTMuMjk3NDMwIiwidXNlcl9pZCI6IlVzZXIwNSIsIm5hbWUiOiJEZWZhdWx0UiBSZWNlcHRpb25pc3QiLCJ1c2VyX3R5cGVfaWQiOjMsInVzZXJfcHJpbWFyeV9pZCI6MTYsImZoaXJfaWQiOiIyNjYiLCJzdWIiOiJuaXNoaXRhQHRoZWxhdHRpY2UuaW4iLCJpYXQiOjE3NzY0MjUwMzQsImV4cCI6MTc3NzAyOTgzNH0.zRAQubqt4khKgQA-oqKrVdSg3yLM50Ho6iTzjl4GwvM"

  if (!baseUrl) {
    console.error(`Unknown env "${env}". Use --base-url or one of: ${Object.keys(SERVER_URLS).join(", ")}`);
    process.exit(1);
  }

  if (!token) {
    console.error(`No token provided. Use --token <your_token> or set the FHIR_TOKEN environment variable.`);
    process.exit(1);
  }

  return { env, baseUrl, dryRun, token };
}

// ─── FILE LOADING ─────────────────────────────────────────────────────────────

function loadSlots(filePath) {
  if (!fs.existsSync(filePath)) {
    console.error(`Slot.json not found at: ${filePath}`);
    process.exit(1);
  }

  const raw = JSON.parse(fs.readFileSync(filePath, "utf-8"));

  if (Array.isArray(raw)) return raw;
  if (raw.resourceType === "Bundle" && Array.isArray(raw.entry)) {
    return raw.entry.map((e) => e.resource).filter(Boolean);
  }
  if (raw.resourceType === "Slot") return [raw];

  console.error("Slot.json must be a FHIR Bundle, array of Slots, or a single Slot resource.");
  process.exit(1);
}

// ─── Slot HELPERS ─────────────────────────────────────────────────────────

function alreadyHasServiceType(Slot) {
  return !!Slot.serviceType;
}

function addServiceType(Slot) {
  return { ...Slot, serviceType: SERVICE_TYPE_TO_ADD };
}

// ─── HTTP REQUEST ─────────────────────────────────────────────────────────────

function httpRequest(url, options, body) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const lib       = parsedUrl.protocol === "https:" ? https : http;

    const reqOptions = {
      hostname: parsedUrl.hostname,
      port:     parsedUrl.port || (parsedUrl.protocol === "https:" ? 443 : 80),
      path:     parsedUrl.pathname + parsedUrl.search,
      method:   options.method ?? "GET",
      headers:  options.headers ?? {},
    };

    const req = lib.request(reqOptions, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        resolve({ status: res.statusCode, statusMessage: res.statusMessage, body: data });
      });
    });

    req.on("error", (err) => {
      if (err.code === "ECONNREFUSED") {
        reject(new Error(`Connection refused at ${parsedUrl.hostname}:${reqOptions.port} — is the server running?`));
      } else if (err.code === "ENOTFOUND") {
        reject(new Error(`Host not found: "${parsedUrl.hostname}" — check your SERVER_URLS config.`));
      } else if (err.code === "ETIMEDOUT") {
        reject(new Error(`Connection timed out to ${url}`));
      } else {
        reject(new Error(`Network error [${err.code}]: ${err.message}`));
      }
    });

    if (body) req.write(body);
    req.end();
  });
}

async function putSlot(baseUrl, token, Slot) {
  const url  = `${baseUrl}/Slot/${Slot.id}`;
  const body = JSON.stringify(Slot);

  const res = await httpRequest(url, {
    method: "PUT",
    headers: {
      "Content-Type":   "application/fhir+json",
      "Content-Length": Buffer.byteLength(body),
      "Authorization":  `Bearer ${token}`,
    },
  }, body);

  if (res.status === 401) {
    throw new Error(`Unauthorized (401) — token is missing, expired, or invalid.`);
  }
  if (res.status === 403) {
    throw new Error(`Forbidden (403) — token does not have permission to update Slots.`);
  }
  if (res.status < 200 || res.status >= 300) {
    throw new Error(`HTTP ${res.status} ${res.statusMessage} — ${res.body}`);
  }

  return JSON.parse(res.body);
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────

async function main() {
  const { env, baseUrl, dryRun, token } = parseCliArgs();

  console.log(`\n🏥  FHIR Slot serviceType Updater`);
  console.log(`   Environment : ${env}`);
  console.log(`   Server URL  : ${baseUrl}`);
  console.log(`   Dry run     : ${dryRun}`);
  console.log(`   Token       : ${token.slice(0, 6)}${"*".repeat(10)} (truncated for safety)`);
  console.log(`   Source file : ${SlotS_FILE}\n`);

  const Slots = loadSlots(SlotS_FILE);
  console.log(`📋  Loaded ${Slots.length} Slot(s) from file.\n`);

  const results = { skipped: 0, updated: 0, failed: 0 };

  for (const Slot of Slots) {
    const id = Slot.id ?? "(no id)";

    if (!Slot.id) {
      console.warn(`  ⚠️  Slot without id — skipped.`);
      results.skipped++;
      continue;
    }

    if (alreadyHasServiceType(Slot)) {
      console.log(`  ⏭️  Slot/${id} — serviceType already present, skipping.`);
      results.skipped++;
      continue;
    }

    const updated = addServiceType(Slot);

    if (dryRun) {
      console.log(`  🔍  [DRY RUN] Would PUT Slot/${id}`);
      console.log(`      serviceType:`, JSON.stringify(updated.serviceType, null, 2));
      results.updated++;
      continue;
    }

    try {
      await putSlot(baseUrl, token, updated);
      console.log(`  ✅  Slot/${id} — updated successfully.`);
      results.updated++;
    } catch (err) {
      console.error(`  ❌  Slot/${id} — FAILED: ${err.message}`);
      results.failed++;
    }
  }

  console.log(`\n📊  Summary`);
  console.log(`   Updated : ${results.updated}`);
  console.log(`   Skipped : ${results.skipped}`);
  console.log(`   Failed  : ${results.failed}\n`);

  if (results.failed > 0) process.exit(1);
}

main();